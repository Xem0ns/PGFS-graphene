// Independent A(1)+B(2), each D18, scalar single-carbon NEP4. GPL-3.0-or-later.
#pragma once
#include "expand_source.cuh"
namespace nep_independent {
constexpr int variables = 175;
constexpr int active_variables = 121; // 54 forbidden cross links; one identifiable sum bias
inline bool a_channel(int d) { return d < 3 || (d >= 6 && (d - 6) % 6 < 3); }
inline bool cross_link(int index) {
  if (index >= 108) return false;
  return (index / 36 == 0) != a_channel(index % 36);
}
template<class P> nep_expand::Source read_source(const P& p) {
  using namespace nep_expand;
  require(p.version==4 && p.num_types==1 && p.elements[0]=="C" &&
    p.train_mode==0 && !p.charge_mode && !p.enable_zbl &&
    !p.use_typewise_cutoff && !p.use_typewise_cutoff_zbl &&
    !p.expand_from && !p.fine_tune && p.prediction==0,
    "independent_branches supports scalar single-C NEP4 training only; incompatible option.");
  require(p.n_max_radial==5 && p.n_max_angular==5 &&
    p.basis_size_radial==4 && p.basis_size_angular==4 &&
    p.L_max==4 && p.L_max_4body==2 && p.L_max_5body==0 &&
    p.num_neurons1==3 && p.dim==36 && p.number_of_variables==variables,
    "independent_branches requires merged 2244 A(1)+B(2), D36 H3, 175 stored parameters.");
  require(std::abs(p.rc_radial-7.0)<1e-6 && std::abs(p.rc_angular-3.5)<1e-6,
    "independent_branches requires cutoff 7 3.5.");
  std::ifstream in(p.independent_branches_file);
  require(in.is_open(),"Cannot open independent_branches source model.");
  auto w=line(in);
  require(w==std::vector<std::string>({"nep4","1","C"}),"Independent source species/version mismatch.");
  w=line(in);
  require((w.size()==3 || w.size()==5) && w[0]=="cutoff" &&
    std::abs(number(w[1])-7.0)<1e-6 && std::abs(number(w[2])-3.5)<1e-6,
    "Independent source cutoff mismatch.");
  fields(line(in),"n_max",{5,5});fields(line(in),"basis_size",{4,4});
  fields(line(in),"l_max",{4,2,0});fields(line(in),"ANN",{3,0});
  Source s;
  for (int i=0;i<variables+36;++i) {
    w=line(in);require(w.size()==1,"Independent source must have one value per line.");
    float v=number(w[0]);require(std::isfinite(v),"Nonfinite independent source parameter.");
    if (i<variables) {
      require(!cross_link(i) || v==0.0f,"Nonzero forbidden A/B cross connection in source.");
      s.parameters.push_back(v);
    } else {require(v>0,"Independent source scaler must be positive.");s.scaler.push_back(v);}
  }
  std::string extra;require(!(in>>extra),"Extra values in independent source.");return s;
}
inline void initialize(const nep_expand::Source& source, float sigma0,
                       std::vector<float>& mu, std::vector<float>& sigma) {
  nep_expand::require(source.parameters.size()==variables && sigma0>0,
                      "Invalid independent initialization.");
  mu=source.parameters;sigma.assign(variables,sigma0);
  for (int i=0;i<variables;++i) if (cross_link(i)) {mu[i]=0;sigma[i]=0;}
}
} // namespace nep_independent
