// Validated scalar NEP3/4 expansion input. GPL-3.0-or-later, like GPUMD.
#pragma once
#include <cmath>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
namespace nep_expand {
struct Source { std::vector<float> parameters, scaler; };
inline void require(bool ok, const char* message) {
  if (!ok) throw std::runtime_error(message);
}
inline std::vector<std::string> line(std::ifstream& in) {
  std::string s, word;
  require(bool(std::getline(in,s)), "Truncated expand_from model.");
  std::istringstream stream(s);
  std::vector<std::string> words;
  while (stream >> word) words.push_back(word);
  require(!words.empty(), "Empty line in expand_from model.");
  return words;
}
inline double number(const std::string& s) {
  size_t used = 0;
  const double x = std::stod(s, &used);
  require(used == s.size() && std::isfinite(x), "Invalid number in expand_from model.");
  return x;
}
inline void fields(const std::vector<std::string>& w, const char* key,
                   const std::vector<double>& expected) {
  require(w.size() == expected.size()+1 && w[0] == key,
          "Incompatible expand_from model header.");
  for (size_t i=0; i<expected.size(); ++i)
    require(std::abs(number(w[i+1])-expected[i]) < 1e-6,
            "expand_from descriptor/header mismatch.");
}
template<class P> Source read_source(const P& p) {
  require(!p.fine_tune, "expand_from cannot be combined with fine_tune.");
  require(p.prediction == 0, "Remove expand_from for prediction; use the saved model directly.");
  require(p.train_mode == 0 && !p.charge_mode && !p.enable_zbl &&
          !p.use_typewise_cutoff && !p.use_typewise_cutoff_zbl &&
          (p.version == 3 || p.version == 4),
          "Validated expansion supports standard scalar NEP3/4 only (no charge/ZBL/typewise cutoff).");
  require(p.expand_from_old_neuron > 0 && p.expand_from_old_neuron < p.num_neurons1,
          "expand_from requires 0 < old_neuron < neuron.");
  require(p.expand_from_freeze >= 0 && p.expand_from_freeze <= 2,
          "Invalid expand_from freeze mode.");
  std::ifstream in(p.expand_from_nep_txt);
  require(in.is_open(), "Cannot open expand_from model.");
  auto w=line(in);
  require(w.size()==size_t(p.num_types+2) &&
          w[0]=="nep"+std::to_string(p.version) && number(w[1])==p.num_types,
          "expand_from version/type-count mismatch.");
  for (int t=0; t<p.num_types; ++t)
    require(w[t+2]==p.elements[t], "expand_from element order mismatch.");
  w=line(in);
  require((w.size()==3 || w.size()==5) && w[0]=="cutoff",
          "Unsupported expand_from cutoff header.");
  require(std::abs(number(w[1])-p.rc_radial)<1e-6 &&
          std::abs(number(w[2])-p.rc_angular)<1e-6, "expand_from cutoff mismatch.");
  fields(line(in),"n_max",{double(p.n_max_radial),double(p.n_max_angular)});
  fields(line(in),"basis_size",{double(p.basis_size_radial),double(p.basis_size_angular)});
  fields(line(in),"l_max",{double(p.L_max),double(p.L_max_4body),double(p.L_max_5body)});
  fields(line(in),"ANN",{double(p.expand_from_old_neuron),0.0});
  const int networks=p.version==3 ? 1 : p.num_types;
  const int count=networks*(p.dim+2)*p.expand_from_old_neuron+1+p.number_of_variables_descriptor;
  Source result;
  for (int i=0; i<count+p.dim; ++i) {
    w=line(in);
    require(w.size()==1,"Expected one parameter per line in expand_from model.");
    float x=number(w[0]);
    require(std::isfinite(x),"expand_from parameter overflows float.");
    if (i<count) result.parameters.push_back(x);
    else {
      require(x>0, "expand_from q_scaler must be positive.");
      result.scaler.push_back(x);
    }
  }
  std::string extra;
  require(!(in >> extra), "Unexpected extra data in expand_from model.");
  return result;
}
} // namespace nep_expand
